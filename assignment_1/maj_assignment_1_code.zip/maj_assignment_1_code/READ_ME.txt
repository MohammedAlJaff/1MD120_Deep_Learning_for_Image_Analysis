FILE: maj_linear_model.py 
    -Inlcudes all implement code for excerise 1.3
    - Is used by the other .py files as a module/lib 


FILE: load_auto.py
    - The provided data-loader python files

All other python files run experiemnts/runs excerises corresponding to each respictve file name. 